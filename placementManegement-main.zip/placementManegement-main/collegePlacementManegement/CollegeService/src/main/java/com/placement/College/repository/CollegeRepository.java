package com.placement.College.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.placement.College.entity.College;

public interface CollegeRepository extends JpaRepository<College, Long>{

}
